#classifica com NB e plota resultados
import pandas as pd

#importing dataset
result = pd.read_csv('categorical.csv', delimiter = ',')
print(result)

#taking the entire text moviment and converting to string
reult = result.dropna( subset = ["texto_movimento_novo"])
result["categorical"] = result["categorical"].apply(lambda x: int(x))


corpus = result["texto_movimento_novo"].values.tolist()
corpus = [str(i) for i in corpus]


from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split


X_train, X_test, y_train, y_test = train_test_split(corpus, result["categorical"].values, test_size=.3, random_state=42)

cv  = TfidfVectorizer(max_features=7000, ngram_range=(1,3), max_df=0.5, min_df=2)
xtrain_tf=cv.fit_transform(X_train)

# Splitting the dataset into the Training set and Test set


#fitting classifier to training set
from sklearn.svm import LinearSVC
from sklearn.linear_model import LogisticRegression
classifier=LinearSVC(class_weight= "balanced")
classifier.fit(xtrain_tf, y_train)


#predicting the test set result

xtest_tf = cv.transform(X_test)
y_pred=classifier.predict(xtest_tf)

dftest = pd.DataFrame(data=X_test)
dftest["labeled"] = y_pred
dftest["ground_truth"] = y_test
dftest.to_csv("avaliar.csv")


#making a confusion matrix
from sklearn.metrics import confusion_matrix, classification_report
cm=confusion_matrix(y_test,y_pred)
print(cm)
print(classification_report(y_test, y_pred))



'''
Plotar resultado
'''
# y_true = ["cat", "ant", "cat", "cat", "ant", "bird"]
# y_pred = ["ant", "ant", "cat", "cat", "ant", "cat"]
# print(confusion_matrix(y_true, y_pred))
#
#
# # Visualising the Test set results
# from matplotlib.colors import ListedColormap
# X_set, y_set = X_test, y_test
#
# X1, X2 = np.meshgrid(np.arange(start = X_set[:, 0].min() - 1, stop = X_set[:, 0].max() + 1, step = 0.01),
#                      np.arange(start = X_set[:, 1].min() - 1, stop = X_set[:, 1].max() + 1, step = 0.01))
#
# plt.contourf(X1, X2, classifier.predict(np.array([X1.ravel(), X2.ravel()]).T).reshape(X1.shape),
#              alpha = 0.75, cmap = ListedColormap(('red', 'green')))
# plt.xlim(X1.min(), X1.max())
# plt.ylim(X2.min(), X2.max())
# for i, j in enumerate(np.unique(y_set)):
#     plt.scatter(X_set[y_set == j, 0], X_set[y_set == j, 1],
#                 c = ListedColormap(('red', 'green'))(i), label = j)
# plt.title('Naive Bayes (Test set)')
# plt.xlabel('Age')
# plt.ylabel('Estimated Salary')
# plt.legend()
# plt.show()
