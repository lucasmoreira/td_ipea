#reverte os resultados de one_hot_encoding para uma coluna categoriga

import numpy as np
import pandas as pd

#importando classificacao dos processos
dataset = pd.read_csv('tmp-sentencas-classificadas.csv', delimiter = '\t')
dataset.drop(columns = ["texto_movimento"],axis = 1, inplace = True)

#importando texto stemizado
dataset_td = pd.read_csv('dados_stemizados.csv', delimiter = ',')

#unindo resultado dos DF pela coluna id de processo
result = pd.concat([dataset, dataset_td["texto_movimento_novo"]], axis=1, sort= False, join="inner")

#fatiando apenas classificacao onehotencoding
encoded_data = result.loc[:,"parcial_proc":"procedente"]
encoded_data = encoded_data.values

# print(result["texto_movimento_novo"])



# encoded_data = encoded_data.groupby(["procedente"]).size()
#funcao para retornar numero equivalente categorigo
# def decode(datum):
#     print(datum)
#     x = sum(datum)
#     if x == 1:
#         return np.argmax(datum)
#     else:
#         return 9

#salva qual o numero corresponde a classificacao em lista
# categorical = []
# for i in range(encoded_data.shape[0]):
#     decoded_datum = decode(encoded_data[i])
#     categorical.append(decoded_datum)

# result["categorical"] = categorical
# result = result[result["categorical"] != 9]
import time
# result["texto_movimento_novo"] = result["texto_movimento_novo"].str.replace(","," ")
# result["texto_movimento"] = result["texto_movimento"].str.replace('\"',"")

def classifica(x):
    x = str(x)
    print(x)
    if "improcedente" in x:
        return 1
    elif "parcialmente" in x:
        if "procedente" in x:
            return 3
        else:
            return 0
    elif "procedente" in x:
        return 2

    else:
        return 0

result["categorical"] = result["texto_movimento_novo"].apply(lambda x: classifica(x))

result = result[result["categorical"] != 0]


print(result["categorical"])


result.to_csv("categorical.csv")
